# Phase 1 Console Application
class User: pass
class Portfolio: pass

def main():
    print("Console App Placeholder")

if __name__=='__main__': main()