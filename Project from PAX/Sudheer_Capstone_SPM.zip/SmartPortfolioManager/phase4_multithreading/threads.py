# Phase 4 Multithreading
import threading

def worker(): print('Thread running')
t=threading.Thread(target=worker); t.start(); t.join()