# Phase 2 Flask API
from flask import Flask
app = Flask(__name__)
@app.get('/')
def home(): return {'msg':'API Placeholder'}
