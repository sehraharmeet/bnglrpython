# Phase 3 PyQt GUI
from PyQt5.QtWidgets import QApplication, QWidget
app = QApplication([])
w = QWidget(); w.show(); app.exec_()