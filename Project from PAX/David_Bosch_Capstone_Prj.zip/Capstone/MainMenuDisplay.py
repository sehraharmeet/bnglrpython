class MainMenuDisplay:

    @staticmethod
    def displayeMainMenu():
            print("""
                  
            ============= CAPSTONE PROJECT ==========
                  
            1.Admin -[Change price of any stock,List all Investors,list individual stocks held by an Investor ]

            2.Investor -[Registor Investors, Buy stocks]

            3.Trader - [Add stocks to be sold, Edit the count of total stocks ]
                  
            4.Exit - [Exit of the application]     

            """)
            