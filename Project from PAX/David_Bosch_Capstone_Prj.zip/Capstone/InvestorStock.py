class InvestorStock:
    def __init__(self, stockName, totalnumberOfStocks, purchasedStockPrice,currentStockPrice):
        self.stockName=stockName
        self.totalnumberOfStocks = totalnumberOfStocks      
        self.eachStock = purchasedStockPrice
        self.currentStockPrice=currentStockPrice
