class SubMenuDisplay:

    @staticmethod
    def displayeSubMenuForAdmin():
            print("""
            1. Edit Price For an existing stock:
                  
            2: Display all the Investors List
                  
            3: Detail list of a Single Investor

            4: Current Portfolio of a Single Investor              


            """)

    @staticmethod
    def displayeSubMenuForInvestor():
            print("""

            1. Add Investor

            2. Buy Stocks
                  
            3. Sell Stocks  

            4. Exit App           

                            

            """)

    @staticmethod
    def displayeSubMenuForTrader():
            print("""

            1. Add New Stock

            2. Edit Existing Stock

            3. Exit The App

            """)

    