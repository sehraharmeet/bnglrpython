#include <string>
#include <format>
#include <vector>
#include <type_traits>
#include <iostream>
#include <chrono>
#include <memory>
#include <thread>
#include <optional>
#include<variant>
#include <algorithm>

using namespace std;
using namespace std::chrono;
 

namespace ExpenseTracker::AppNs{

    template<typename T>
    concept Numeric = is_arithmetic_v<T>;


    enum class ExpTrackerType { Income, Expense };

    struct Transaction {
        int id;
        string title;
        variant<double,string> amount;
        ExpTrackerType type;
        string category;
        int64_t timestamp;
    };

    


    class Tracker {
    private:
        vector<unique_ptr<Transaction>> records;
        int nextId = 1;

    public:

        template<Numeric T>
        T AllowOnlyNumeric(T a)
        {
            return a;
        }

        void addTransaction()
        {
            string title, category;
            double amount;
            int typeChoice;

            cout << "Enter Title: ";
            cin >> title;

            cout << "Enter Amount: ";
            cin >> amount;

            cout << "1. Income  2. Expense : ";
            cin >> typeChoice;

            cout << "Enter Category: ";
            cin >> category;

            auto txn = make_unique<Transaction>();
            txn->id = nextId++;
            txn->title = title;
            txn->amount = amount;
            txn->type = (typeChoice == 1) ? ExpTrackerType::Income : ExpTrackerType::Expense;
            txn->category = category;

            auto now = system_clock::now();

            int64_t timestamp = duration_cast<seconds>(
                now.time_since_epoch()).count();
			txn->timestamp = timestamp;// Task 10 – Calendar



            records.push_back(move(txn));
            cout << "Transaction Added!\n";
        }

        void showAll() const
        {
            for (const auto& txn : records)
            {
                if(holds_alternative<double>(txn->amount)) //Task 6 – std::variant

                cout << txn->id << " | "<< txn->title << " | "<< get<double>(txn->amount) << " | " << txn->category << " | "<< (txn->type == ExpTrackerType::Income ? "Income" : "Expense")<< endl;
            }
        }

        void filterByCategoryUsingLambda(string selectedCategory)  // Task 2 – Lambda Filtering
        {

            for_each(records.begin(), records.end(), [selectedCategory](const auto& tranPtr) {

                if (tranPtr->category == selectedCategory) {
                    cout << tranPtr->id << " | " << tranPtr->title << " | " << get<double>(tranPtr->amount) << " | " << tranPtr->category << " | " << (tranPtr->type == ExpTrackerType::Income ? "Income" : "Expense") << endl;
                }
                });
		}


        template <typename myContainer> // Task 1 – Template Utility 
        typename myContainer::value_type showSummaryTAD(const myContainer & mycon)
        {
            return accumulate(mycon.begin(), mycon.end(), typename myContainer::value_type{});
        }
        

        void showSummary()
        {

            double income = 0, expense = 0;

            for (const auto& txn : records)
            {
                if (std::holds_alternative<double>(txn->amount)) { //Task 6 – std::variant 

                    if (txn->type == ExpTrackerType::Income){
                        income += get<double>(txn->amount);

                        /*std::visit([&income](double amt) {
                            income += amt;
                            }, txn->amount);*/
                    }
                    else
                    {
                       /* std::visit([&expense](double amt) {
                            expense += amt;
                            }, txn->amount);*/

                            expense += get<double>(txn->amount);
                    }
                        

                }
            }

            cout << "\nTotal Income: " << income;
            cout << "\nTotal Expense: " << expense;
            cout << "\nBalance: " << income - expense << endl;
        }


        optional<Transaction> findTransacationByIdUsingOptional(int transactionId) {  //Task 5 – std::optional

            for (const auto& txn : records)
                if (txn->id == transactionId)
					return *txn;
            std::nullopt;
        }

		void showIncomeUsingMT() //Task 9 – Multithreading Summary for Income
        {
           
            for (const auto& txn : records)
                if ((txn->type == ExpTrackerType::Income) && (holds_alternative<double>(txn->amount)))
                    cout << "Id = " << txn->id << "Title = " << "txn->title" << "Amount = " <<get<double>(txn->amount) << "Timestamp = " << txn->timestamp << endl;
        }

		void showExpenseUsingMT() //Task 9 – Multithreading Summary for Expense
        {

            for (const auto& txn : records)
                if ((txn->type == ExpTrackerType::Expense) && (holds_alternative<double>(txn->amount)))
                    cout << "Id = " << txn->id << "Title = " << "txn->title" << "Amount = "<< get<double>(txn->amount) << "Timestamp = " << txn->timestamp << endl;
        }

        template<typename... Args> //Task 3 – Variadic Template Logging
        void eTrackerLogging(Args... args)
        {
            ((cout << args << std::endl), ...);
        }


    };

}
