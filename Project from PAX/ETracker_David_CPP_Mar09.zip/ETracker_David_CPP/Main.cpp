#include <iostream>
#include "Transaction.h"
#include <string>
#include <thread>

using namespace ExpenseTracker::AppNs;

int main()
{
	
    Tracker tracker;
    int choice;

    do {
        cout << "\n===== Income & Expense Tracker =====\n";
        cout << "1. Add Transaction\n";
        cout << "2. Show All\n";
        cout << "3. Show Summary\n";
        cout << "5. Find a transaction using Optional \n";
        cout << "91. Multithreading Summary Income\n";
        cout << "92. Multithreading Summary Expense\n";
        cout << "10. Calendar\n";
        cout << "4. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice)
        {
        case 1: tracker.addTransaction(); break;
        case 2: tracker.showAll(); break;
        case 3: tracker.showSummary(); break;
        case 5: { //Task 5 – std::optional
            int transactionId;
            cout << "Enter Transaction ID to find: "<<endl;
            cin >> transactionId;
            auto result = tracker.findTransacationByIdUsingOptional(transactionId);
            if (result)
                cout << "Transaction Found: "<< endl;
            else
                cout << "Transaction not found.\n";
            break;
			}
        case 91:{ //Task 9 – Multithreading Summary 
            thread obj(&Tracker::showIncomeUsingMT, &tracker);
            obj.join();
            break;
        }
        case 92: { //Task 9 – Multithreading Summary 
            thread obj(&Tracker::showIncomeUsingMT, &tracker);
            obj.join();
             break;
        }
        case 10: tracker.showSummary(); break;
        }

    } while (choice != 4);

    return 0;

}