from Utils.FileHandler import FileHandler


class Market:
    JSON_FILE = "UserData/markets.json"
    market_obj = FileHandler()

    def view_market(self):
        market_list = self.market_obj.file_read(self.JSON_FILE)
        return market_list
