import json
from Utils.FileHandler import FileHandler
from models.market import Market


class User:
    JSON_FILE = "UserData/users.json"
    file_obj = FileHandler()
    market_obj = Market()
    MARKET_JSON = "UserData/markets.json"

    def add_details(self):
        data = self.file_obj.file_read(self.JSON_FILE)

        if "users" not in data:
            data["users"] = {}

        while True:
            ID = input("create your Id:")
            if not (ID.isdigit()):
                print("Enter digits only")
                continue

            if ID in data["users"]:
                print("ID already exists!")
                continue
            print("ID created!")
            break

        name = input("enter your name:")
        store = {
            "Name": name,
            "balance": 0,
            "portfolio": {}
        }
        data["users"][ID] = store
        self.file_obj.file_write(self.JSON_FILE, data)
        print("Account created successfully!\nPlease remember your Details.\n")

    def login_details(self, ID, name):
        data = self.file_obj.file_read(self.JSON_FILE)
        if ID in data["users"] and data["users"][ID]["Name"] == name:
            print("ID,Name found.Login succesfull")
            return True

        print("Wrong details!")
        return False

    def add_funds(self, ID, funds):
        data = self.file_obj.file_read(self.JSON_FILE)
        data["users"][ID]["balance"] += funds
        self.file_obj.file_write(self.JSON_FILE, data)
        print("Amount added succesfully")

    def user_balance(self, amount, ID, stock_name, stock_qty):
        data = self.file_obj.file_read(self.JSON_FILE)
        market = self.market_obj.view_market()
        market_data = market['market']
        if data["users"][ID]["balance"] > amount:
            data["users"][ID]["balance"] -= amount
            portfolio = data["users"][ID]["portfolio"]
            if stock_name in portfolio:
                portfolio = {"stock_quantity": stock_qty + data["users"][ID]["portfolio"][stock_name]["stock_quantity"],
                             "average_buy_price": market_data[stock_name]["current_price"],
                             "total_cost_invested": int((stock_qty * market_data[stock_name]["current_price"]) +
                                                        data["users"][ID]["portfolio"][stock_name][
                                                            "total_cost_invested"])}
                data["users"][ID]["portfolio"][stock_name] = portfolio
            else:
                portfolio[stock_name] = {
                    "stock_quantity": stock_qty,
                    "average_buy_price": market_data[stock_name]["current_price"],
                    "total_cost_invested": stock_qty * market_data[stock_name]["current_price"]
                }

            self.file_obj.file_write(self.JSON_FILE, data)
            return True
        else:
            return False

    def sell_stock_user_balance(self, ID, stock_name, sell_qty):
        data = self.file_obj.file_read(self.JSON_FILE)
        market = self.market_obj.view_market()
        market_data = market['market']

        remove_user_qty = data["users"][ID]["portfolio"][stock_name]["stock_quantity"]
        portfolio = data["users"][ID]["portfolio"]
        if sell_qty > remove_user_qty:
            print("Not enough shares to sell")
            return False

        elif sell_qty < remove_user_qty:
            final_sell_qty = remove_user_qty - sell_qty
            portfolio = {"stock_quantity": final_sell_qty,
                         "average_buy_price": market_data[stock_name]["current_price"],
                         "total_cost_invested": int(final_sell_qty * market_data[stock_name]["current_price"])
                         }

            data["users"][ID]["portfolio"][stock_name] = portfolio
            data["users"][ID]["balance"] += sell_qty * market_data[stock_name]["current_price"]
            self.file_obj.file_write(self.JSON_FILE, data)
            return True

        elif remove_user_qty == sell_qty:
            portfolio.pop(stock_name)
            data["users"][ID]["balance"] += sell_qty * market_data[stock_name]["current_price"]
            self.file_obj.file_write(self.JSON_FILE, data)
            return True

        else:
            print("Your stock not sold")
            return False
