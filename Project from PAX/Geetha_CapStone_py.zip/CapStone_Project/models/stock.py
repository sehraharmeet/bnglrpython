from Utils.FileHandler import FileHandler
from models.market import Market
from models.users import User


class Stock:
    stock_file = FileHandler()
    user_obj = User()
    market_obj = Market()
    market_filepath = "UserData/markets.json"
    user_filepath = "UserData/users.json"

    def buy_stock(self, stock, stock_qty, user_id):
        market = self.market_obj.view_market()
        market_data = market['market']
        if stock_qty <= market_data[stock]["available_quantity"]:
            amount = stock_qty * market_data[stock]["current_price"]
            if self.user_obj.user_balance(amount, user_id, stock, stock_qty):
                update_qty = market_data[stock]["available_quantity"] - stock_qty
                market_data[stock]['available_quantity'] = update_qty
                self.stock_file.file_write(self.market_filepath, market)
                print("Stock bought successfully")
            else:
                print("Insufficient funds")

    def sell_stock(self, ID, stock_name):
        user_file = self.stock_file.file_read(self.user_filepath)
        if stock_name in user_file["users"][ID]["portfolio"]:
            sell_qty = int(input('Enter quantity to sell:'))
            if self.user_obj.sell_stock_user_balance(ID, stock_name, sell_qty):
                market = self.market_obj.view_market()
                market_data = market['market']
                if sell_qty <= market_data[stock_name]['available_quantity']:
                    market_data[stock_name]['available_quantity'] = market_data[stock_name][
                                                                        'available_quantity'] + sell_qty
                    self.stock_file.file_write(self.market_filepath, market)
                    print("Stock sold")
        else:
            print("Invalid stock name or stock not present in portfolio ")
