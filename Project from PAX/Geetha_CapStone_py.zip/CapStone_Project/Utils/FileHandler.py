import json


class FileHandler:
    @staticmethod
    def file_read(filename):
        with open(filename, "r") as file:
            data = json.load(file)
        return data

    @staticmethod
    def file_write(filename, data):
        with open(filename, "w") as file:
            json.dump(data, file, indent=4)
