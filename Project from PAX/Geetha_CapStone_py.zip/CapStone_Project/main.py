from Utils.FileHandler import FileHandler
from models.market import Market
from models.stock import Stock
from models.users import User

user_obj = User()
market_obj = Market()
stock_obj = Stock()
file_obj = FileHandler()
user_file = "UserData/users.json"

while True:
    print("************SMART PORTFOLIO****************")
    print("Please choose a option from below menu:")
    print("1. Register User")
    print("2. Login as user")
    print("3. View Market")
    print("4. Exit")
    choice = int(input("Enter your choice:"))

    if choice == 1:
        user_obj.add_details()

    elif choice == 2:
        ID = input("Enter your Id:")
        name = input("Enter your name:")
        if user_obj.login_details(ID, name):
            while True:
                print("-----------------------------------------------")
                print("1. Add funds")
                print("2. Buy stock")
                print("3. Sell stock")
                print("4. Track Portfolio")
                print("5. View Balance")
                print("6. Exit")
                choice = int(input("Enter your choice:"))
                if choice == 1:
                    funds = int(input("Enter amount:"))
                    user_obj.add_funds(ID, funds)

                elif choice == 2:
                    print("Select your Stock from below data:")
                    market = market_obj.view_market()
                    market_list = market['market']
                    print("Company  AvailableQuantity   CurrentPrice ")
                    for key, value in market_list.items():
                        print(f"{key}\t \t {value["available_quantity"]}\t \t {value["current_price"]}")
                    stock = input("Enter the stock name:")
                    if stock in market_list:
                        stock_qty = int(input("Enter the stock quantity:"))
                        stock_obj.buy_stock(stock, stock_qty, ID)
                    else:
                        print("Invalid stock name")

                elif choice == 3:
                    data = file_obj.file_read(user_file)
                    if data["users"][ID]["portfolio"] != {}:
                        print("Company     Available stock quantity")
                        for key, value in data["users"][ID]["portfolio"].items():
                            print(f"{key}\t \t {value["stock_quantity"]}")
                        stock_name = input("Enter the stock name to sell:")
                        stock_obj.sell_stock(ID, stock_name)
                    else:
                        print("No stocks available to sell")

                elif choice == 4:
                    data = file_obj.file_read(user_file)
                    if data["users"][ID]["portfolio"] != {}:
                        print("Company   Available stock quantity   Buy_Price  Total Cost Invested")
                        for key, value in data["users"][ID]["portfolio"].items():
                            print(
                                f"{key}\t \t \t \t{value["stock_quantity"]}\t \t \t \t{value["average_buy_price"]}\t \t \t \t{value["total_cost_invested"]}")
                    else:
                        print("Your portfolio is empty")

                elif choice == 5:
                    data = file_obj.file_read(user_file)
                    total_bal = data["users"][ID]["balance"]
                    print(f"Your Available Balance Currently: {total_bal}")

                elif choice == 6:
                    quit()
        else:
            print("Login not Successfull")

    elif choice == 3:
        market = market_obj.view_market()
        market_list = market['market']
        for key, value in market_list.items():
            print(f"Company            : {key}")
            print(f"Sector             : {value["sector"]}")
            print(f"Current_Price      : {value["current_price"]}")
            print(f"Available_Quantity : {value["available_quantity"]}")
            print(f"Day_High           : {value["day_high"]}")
            print(f"Day_Low            : {value["day_low"]}")
            print("-" * 10)

    elif choice == 4:
        quit()
    else:
        print("Invalid entry,Please try again\n")
